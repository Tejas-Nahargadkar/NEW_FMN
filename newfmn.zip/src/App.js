import React from 'react';
import './App.css';
import JobSeekerdashboard from './components/JOBSeek/JobSeekerdashboard';

function App() {
  return (
    <div className="App">
     <JobSeekerdashboard/>
   
    </div>
  );
}

export default App;
